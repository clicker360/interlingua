<!DOCTYPE html>
<html lang="es">
<head>
  <script type="text/javascript">

      var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-8156648-1']);
      _gaq.push(['_setDomainName', 'interlingua.com.mx']);
      _gaq.push(['_trackPageview']);

      (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();

  </script>
  
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0">
	<title>Interlingua - Inglés para la vida</title>
	<link href="style.css" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Cabin:400,400italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Muli:300,400,300italic,400italic' rel='stylesheet' type='text/css'>
    <link type="text/css" rel="stylesheet" href="lightbox-form.css">

    <!-- Add jQuery library -->
  <script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>

  
  <!-- Add fancyBox main JS and CSS files -->
  <script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.4"></script>
  <link rel="stylesheet" type="text/css" href="js/jquery.fancybox.css?v=2.1.4" media="screen" />

 
  
  <script type="text/javascript">
    $(document).ready(function() {
      /*
       *  Simple image gallery. Uses default settings
       */

      $('.fancybox').fancybox({
          'width': 500,
          'height': 400,
          'autoSize': false

        });
    });
  </script>

</head>

 
<body>



	<div id="pt1"></div>

	 <div id="pagewrap">

  		<header>
  			<div id="logo"></div>
          <div id="header-derecho">
              
              <div id="linea1">Línea de atención al cliente <strong>01 800 1 INGLÉS  (464537)</strong></div>
              
              <div id="linea2">Centro de información Cd. de México<strong> 500 500 50</strong></div>
             
              <div id="social">
                  <div id="interlingua"><a href="http://www.interlingua.com.mx" target="_blank"><img src="images/interlingua.png" width="33" height="33"></a></div>
                  <div id="facebook"><a href="https://www.facebook.com/interlingua.mx?fref=ts" target="_blank"><img src="images/facebook.png" width="33" height="33"></a></div>
                  <div id="twitter"><a href="https://twitter.com/Interlinguamx" target="_blank"><img src="images/twitter.png" width="33" height="33"></a></div>
              </div>
          </div>
  		</header>

<div id="contenido">
		<div id="wrap">
			<section>
			 <div id="slogan">
          <div id="bueno"> <strong>Bueno:</strong><br> Tus hijos van al colegio.</div>
          <div id="malo"> <strong>Malo:</strong> <br>No tienen que hacer<br>en las tardes.</div>
          <div id="excelente"> <strong>Excelente:</strong><br> Tenemos increíbles <br>cursos para ellos.</div>
       </div>
       <div id="bottom-slogan"></div>
			</section>
	
			<aside id="sidebar">	
        <div id="p3"><img src="images/encabezado.png" width="220" height="202"></div>
			 
				<div id="p4">¡Inscríbelos a <br><strong>INTERLINGUA</strong><br>y dales una herramienta<br> para la vida!</div>

 
<input type="submit" href="registro.html" id="btnlightbox" class="fancybox fancybox.iframe" value="¡Aparta su lugar aquí!" style="cursor:pointer" />

<!--<a id=" btnlightbox" class="fancybox fancybox.iframe" href="iframe.html">Iframe</a> -->

</div>    
</div> 	 
</aside>

	<div id="contenido1">
 			<div id="sombra"></div>   
	</div>

<div id="beneficios">
   <div id="beneficios1" class="fancybox fancybox.iframe"   href="registro.html"><strong>Clases a partir<br> de las<br>2:00 de la tarde</strong> </div>
  <div id="beneficios2" class="fancybox fancybox.iframe"   href="registro.html"><strong>Incluye<br> libro de<br> trabajo</strong></div>
 <div id="beneficios3" class="fancybox fancybox.iframe"   href="registro.html"><strong></br>Excelente<br>ambiente<br> para tus niños</strong></div>

</div>

<div id="sombras-beneficios">
  <div id="s-beneficios1">
  </div>
  <div id="s-beneficios2">
  </div>
  <div id="s-beneficios3">
  </div>
</div>


    
   
    
   
  </form>
</div>


 
  


       
<footer>
  <div id="pie">
    <div id="copyright">Todos los derechos reservados © Interlingua 2013</div>
    <div id="aviso"><a href="politicas.html" target="_blank">Aviso Privacidad</a></div>
  </div>
</footer>

</body>
</html>
