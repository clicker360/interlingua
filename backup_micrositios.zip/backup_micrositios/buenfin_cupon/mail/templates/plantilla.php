<html>
<head>
<title>Interlingua - El Buen Fin</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body bgcolor="#EEE" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- Save for Web Slices (http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon.psd) -->
<table id="Tabla_01" width="650" height="766" border="0" cellpadding="0" cellspacing="0" style="margin:0 auto; border-collapse:collapse; padding:0;">
	<tr>
		<td colspan="9">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_01.jpg" width="650" height="75" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_02.jpg" width="94" height="104" alt="" style="display:block;"></td>
		<td height="96" colspan="5" style="padding:0px;background-color:#0099a9; color:#FFF; font-family:'Myriad Pro', 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size:24px; text-align:center; font-weight:bold">
			&iexcl;Imprime este mail y recibe <span style="color:#e5dc44">GRATIS
              <br>
          el curso de Diciembre 2013</span>
          <br>
      al inscribirte para Enero de 2014&#33; &#42;</td>
		<td colspan="2">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_04.jpg" width="94" height="104" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td colspan="9">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_05.jpg" width="650" height="143" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_06.jpg" width="137" height="34" alt="" style="display:block;"></td>
		<td colspan="5" style="padding:0px;background-color:#f7f7f7; text-align:center; font-family:'Myriad Pro', 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size:24px; color:#08596e;">
			<strong><?php echo $nombre; ?></strong></td>
		<td>
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_08.jpg" width="66" height="34" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td colspan="9">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_09.jpg" width="650" height="170" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td colspan="9">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_10.jpg" width="650" height="140" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td>
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_11.jpg" width="49" height="19" alt=""></td>
		<td colspan="5">
			<a href="http://www.interlingua.com.mx/">
				<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_12.jpg" width="186" height="19" border="0" alt="" style="display:block;"></a></td>
		<td colspan="3">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_13.jpg" width="415" height="19" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td colspan="4">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_14.jpg" width="159" height="31" alt="" style="display:block;"></td>
		<td>
			<a href="https://www.facebook.com/interlingua.mx?ref=hl">
				<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_13-16.jpg" width="34" height="31" border="0" alt="" style="display:block;"></a></td>
		<td>
			<a href="https://twitter.com/Interlinguamx">
				<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_14-17.jpg" width="42" height="31" border="0" alt="" style="display:block;"></a></td>
		<td colspan="3">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_17.jpg" width="415" height="31" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td colspan="9">
			<img src="http://www.interlingua.com.mx/buenfin_cupon/mail/templates/131106_Interlingua-Cupon_18.jpg" width="650" height="49" alt="" style="display:block;"></td>
	</tr>
	<tr>
		<td>
			<img src="espacio.gif" width="49" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="45" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="43" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="22" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="34" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="42" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="321" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="28" height="1" alt="" style="display:block;"></td>
		<td>
			<img src="espacio.gif" width="66" height="1" alt="" style="display:block;"></td>
	</tr>
</table>
<!-- End Save for Web Slices -->
</body>
</html>